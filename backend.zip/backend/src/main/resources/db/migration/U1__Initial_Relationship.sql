DROP TABLE addresses;

DROP TABLE users;

DROP TABLE roles;