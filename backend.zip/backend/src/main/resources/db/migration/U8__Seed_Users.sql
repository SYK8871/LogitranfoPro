DELETE FROM users_roles;
DELETE FROM users;
DELETE FROM roles;