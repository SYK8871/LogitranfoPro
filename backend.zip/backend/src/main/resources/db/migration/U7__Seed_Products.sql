DELETE FROM products;
DELETE FROM product_categories;