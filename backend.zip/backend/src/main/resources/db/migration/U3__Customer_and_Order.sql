DROP TABLE customers;

DROP TABLE orders;

DROP TABLE order_items;