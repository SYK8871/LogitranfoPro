DROP TABLE product_categories;

DROP TABLE products;

DROP TABLE roles;