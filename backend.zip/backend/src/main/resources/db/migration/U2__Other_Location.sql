DROP TABLE countries;

DROP TABLE states;

DROP TABLE roles;