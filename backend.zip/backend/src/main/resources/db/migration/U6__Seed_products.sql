DELETE FROM countries;
DELETE FROM states;

